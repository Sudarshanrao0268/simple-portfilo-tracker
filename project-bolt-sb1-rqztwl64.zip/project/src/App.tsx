import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { StockList } from './components/StockList';
import { StockForm } from './components/StockForm';
import { Stock, PortfolioMetrics } from './types/stock';
import { getStockQuote } from './services/api/alphaVantage';

function App() {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingStock, setEditingStock] = useState<Stock | undefined>();
  const [metrics, setMetrics] = useState<PortfolioMetrics>({
    totalValue: 0,
    totalGainLoss: 0,
    topPerformer: null,
    worstPerformer: null,
  });

  useEffect(() => {
    const savedStocks = localStorage.getItem('stocks');
    if (savedStocks) {
      setStocks(JSON.parse(savedStocks));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('stocks', JSON.stringify(stocks));
    updateMetrics();
  }, [stocks]);

  const updateMetrics = () => {
    const totalValue = stocks.reduce((sum, stock) => sum + stock.currentPrice * stock.quantity, 0);
    const totalGainLoss = stocks.reduce(
      (sum, stock) => sum + (stock.currentPrice - stock.buyPrice) * stock.quantity,
      0
    );

    const sortedByPerformance = [...stocks].sort(
      (a, b) =>
        (b.currentPrice - b.buyPrice) / b.buyPrice -
        (a.currentPrice - a.buyPrice) / a.buyPrice
    );

    setMetrics({
      totalValue,
      totalGainLoss,
      topPerformer: sortedByPerformance[0] || null,
      worstPerformer: sortedByPerformance[sortedByPerformance.length - 1] || null,
    });
  };

  const handleAddStock = async (stockData: Omit<Stock, 'id' | 'currentPrice'>) => {
    try {
      const currentPrice = await getStockQuote(stockData.symbol);
      const newStock: Stock = {
        ...stockData,
        id: Date.now().toString(),
        currentPrice,
      };
      setStocks([...stocks, newStock]);
    } catch (error) {
      console.error('Error adding stock:', error);
      // Handle error (show notification, etc.)
    }
  };

  const handleEditStock = async (stockData: Omit<Stock, 'id' | 'currentPrice'>) => {
    if (!editingStock) return;
    
    try {
      const currentPrice = await getStockQuote(stockData.symbol);
      const updatedStock: Stock = {
        ...stockData,
        id: editingStock.id,
        currentPrice,
      };
      
      setStocks(stocks.map((s) => (s.id === editingStock.id ? updatedStock : s)));
      setEditingStock(undefined);
    } catch (error) {
      console.error('Error updating stock:', error);
      // Handle error (show notification, etc.)
    }
  };

  const handleDeleteStock = (id: string) => {
    setStocks(stocks.filter((s) => s.id !== id));
  };

  const handlePriceUpdate = (id: string, price: number) => {
    setStocks(stocks.map((stock) => 
      stock.id === id ? { ...stock, currentPrice: price } : stock
    ));
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Portfolio Tracker</h1>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Stock
          </button>
        </div>

        <Dashboard metrics={metrics} />
        
        <StockList
          stocks={stocks}
          onEdit={(stock) => {
            setEditingStock(stock);
            setShowForm(true);
          }}
          onDelete={handleDeleteStock}
          onPriceUpdate={handlePriceUpdate}
        />

        {showForm && (
          <StockForm
            stock={editingStock}
            onSubmit={editingStock ? handleEditStock : handleAddStock}
            onClose={() => {
              setShowForm(false);
              setEditingStock(undefined);
            }}
          />
        )}
      </div>
    </div>
  );
}

export default App;