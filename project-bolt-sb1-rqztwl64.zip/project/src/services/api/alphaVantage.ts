import axios, { AxiosError } from 'axios';
import { API_CONFIG } from '../../config/api';
import { AlphaVantageQuote, AlphaVantageError } from './types';

const { BASE_URL, API_KEY, ENDPOINTS } = API_CONFIG.ALPHA_VANTAGE;

class RateLimitError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RateLimitError';
  }
}

class APIError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'APIError';
  }
}

export async function getStockQuote(symbol: string): Promise<number> {
  try {
    const response = await axios.get<AlphaVantageQuote | AlphaVantageError>(BASE_URL, {
      params: {
        function: ENDPOINTS.QUOTE,
        symbol,
        apikey: API_KEY,
      },
    });

    // Check for rate limit or API errors
    if ('Note' in response.data) {
      throw new RateLimitError(response.data.Note || 'Rate limit exceeded');
    }

    if ('Information' in response.data) {
      throw new APIError(response.data.Information || 'API error occurred');
    }

    const quote = response.data as AlphaVantageQuote;
    const price = parseFloat(quote['Global Quote']['05. price']);

    if (isNaN(price)) {
      throw new Error('Invalid price data received');
    }

    return price;
  } catch (error) {
    if (error instanceof RateLimitError) {
      console.error('Rate limit exceeded:', error.message);
      // Return last known price or throw error based on your requirements
      throw error;
    }

    if (error instanceof APIError) {
      console.error('API error:', error.message);
      throw error;
    }

    if (error instanceof AxiosError) {
      console.error('Network error:', error.message);
      throw new Error('Failed to fetch stock price');
    }

    console.error('Unexpected error:', error);
    throw error;
  }
}