import React from 'react';
import { useStockPrice } from '../hooks/useStockPrice';
import { AlertCircle, Loader } from 'lucide-react';

interface StockPriceProps {
  symbol: string;
  onPriceUpdate?: (price: number) => void;
}

export function StockPrice({ symbol, onPriceUpdate }: StockPriceProps) {
  const { price, error, loading } = useStockPrice(symbol);

  React.useEffect(() => {
    if (price && onPriceUpdate) {
      onPriceUpdate(price);
    }
  }, [price, onPriceUpdate]);

  if (loading) {
    return (
      <div className="flex items-center text-gray-500">
        <Loader className="h-4 w-4 animate-spin mr-2" />
        Loading...
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center text-red-500">
        <AlertCircle className="h-4 w-4 mr-2" />
        {error.message}
      </div>
    );
  }

  return <span className="font-medium">${price.toFixed(2)}</span>;
}