import { useState, useEffect } from 'react';
import { getStockQuote } from '../services/api/alphaVantage';

export function useStockPrice(symbol: string, interval = 60000) {
  const [price, setPrice] = useState<number>(0);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    let mounted = true;

    async function updatePrice() {
      try {
        setLoading(true);
        const newPrice = await getStockQuote(symbol);
        if (mounted) {
          setPrice(newPrice);
          setError(null);
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err : new Error('Failed to fetch price'));
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    updatePrice();
    const timer = setInterval(updatePrice, interval);

    return () => {
      mounted = false;
      clearInterval(timer);
    };
  }, [symbol, interval]);

  return { price, error, loading };
}