export const API_CONFIG = {
  ALPHA_VANTAGE: {
    BASE_URL: 'https://www.alphavantage.co/query',
    API_KEY: 'H5XCUHBAU7PAZ9IN',
    ENDPOINTS: {
      QUOTE: 'GLOBAL_QUOTE',
      SEARCH: 'SYMBOL_SEARCH',
    },
    RATE_LIMIT: {
      REQUESTS_PER_MINUTE: 5,
      REQUESTS_PER_DAY: 500,
    },
  },
};